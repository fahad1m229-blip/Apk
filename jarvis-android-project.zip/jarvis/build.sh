#!/usr/bin/env bash
# Needs: JDK 17, Android SDK (ANDROID_HOME set, platform 34), Gradle 8.7+
set -e
gradle :app:assembleDebug
mkdir -p APK_DOWNLOAD .build-outputs
cp app/build/outputs/apk/debug/app-debug.apk APK_DOWNLOAD/app-debug.apk
cp app/build/outputs/apk/debug/app-debug.apk .build-outputs/app-debug.apk
S=$(stat -c%s APK_DOWNLOAD/app-debug.apk 2>/dev/null || stat -f%z APK_DOWNLOAD/app-debug.apk)
[ "$S" -gt 1048576 ] && echo "OK: real APK, $S bytes" || { echo "APK too small"; exit 1; }
