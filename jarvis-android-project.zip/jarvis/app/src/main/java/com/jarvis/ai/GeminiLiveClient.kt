package com.jarvis.ai

import android.util.Base64
import okhttp3.*
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Gemini Live (BidiGenerateContent) WebSocket client. Auth via header so the key never appears in a URL. */
class GeminiLiveClient(private val l: Listener) {
    interface Listener {
        fun onReady()
        fun onAudio(pcm24k: ByteArray)
        fun onInterrupted()
        fun onTurnComplete()
        fun onToolCall(id: String, name: String, args: JSONObject)
        fun onError(msg: String)
        fun onClosed()
    }

    private val http = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()
    private var ws: WebSocket? = null
    @Volatile private var open = false

    fun connect(apiKey: String, model: String, systemPrompt: String, tools: JSONArray) {
        val req = Request.Builder()
            .url("wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent")
            .header("x-goog-api-key", apiKey).build()
        ws = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) {
                val setup = JSONObject().put("setup", JSONObject().apply {
                    put("model", if (model.startsWith("models/")) model else "models/$model")
                    put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO")))
                    put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
                    if (tools.length() > 0) put("tools", tools)
                })
                w.send(setup.toString())
            }
            override fun onMessage(w: WebSocket, text: String) = handle(text)
            override fun onMessage(w: WebSocket, bytes: ByteString) = handle(bytes.utf8())
            override fun onFailure(w: WebSocket, t: Throwable, r: Response?) {
                open = false
                l.onError("Connection failed: ${r?.code ?: t.javaClass.simpleName}")
            }
            override fun onClosed(w: WebSocket, code: Int, reason: String) { open = false; l.onClosed() }
        })
    }

    private fun handle(raw: String) {
        val o = JSONObject(raw)
        if (o.has("setupComplete")) { open = true; l.onReady() }
        o.optJSONObject("serverContent")?.let { sc ->
            if (sc.optBoolean("interrupted")) l.onInterrupted()
            sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) {
                    parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data")?.takeIf { it.isNotEmpty() }
                        ?.let { l.onAudio(Base64.decode(it, Base64.DEFAULT)) }
                }
            }
            if (sc.optBoolean("turnComplete")) l.onTurnComplete()
        }
        o.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { calls ->
            for (i in 0 until calls.length()) {
                val c = calls.getJSONObject(i)
                l.onToolCall(c.optString("id"), c.getString("name"), c.optJSONObject("args") ?: JSONObject())
            }
        }
    }

    fun sendAudio(pcm16k: ByteArray) {
        if (!open) return
        val msg = JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject()
            .put("data", Base64.encodeToString(pcm16k, Base64.NO_WRAP))
            .put("mimeType", "audio/pcm;rate=16000")))
        ws?.send(msg.toString())
    }

    fun sendToolResult(id: String, name: String, result: JSONObject) {
        val msg = JSONObject().put("toolResponse", JSONObject().put("functionResponses", JSONArray().put(
            JSONObject().put("id", id).put("name", name).put("response", result))))
        ws?.send(msg.toString())
    }

    fun close() { open = false; ws?.close(1000, null); ws = null }
}
