package com.jarvis

import android.app.Application
import com.jarvis.ai.AppConfig
import com.jarvis.ai.SecureKeyStore
import com.jarvis.tools.BatteryTool
import com.jarvis.tools.GetTimeTool
import com.jarvis.tools.ToolRegistry

class JarvisApp : Application() {
    lateinit var keyStore: SecureKeyStore
    lateinit var config: AppConfig
    val tools = ToolRegistry()

    override fun onCreate() {
        super.onCreate()
        keyStore = SecureKeyStore(this)
        config = AppConfig(this)
        // New capabilities = register a new JarvisTool here. Nothing else changes.
        tools.register(GetTimeTool())
        tools.register(BatteryTool(this))
    }
}
