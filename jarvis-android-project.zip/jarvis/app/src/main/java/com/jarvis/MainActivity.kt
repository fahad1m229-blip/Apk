package com.jarvis

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.jarvis.ai.GeminiApi
import com.jarvis.voice.JarvisVoiceService
import com.jarvis.voice.VoiceState
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as JarvisApp
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    var settings by remember { mutableStateOf(false) }
                    if (settings) SettingsScreen(app) { settings = false } else HomeScreen(app) { settings = true }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(app: JarvisApp, openSettings: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val state by JarvisVoiceService.state.collectAsState()
    val error by JarvisVoiceService.error.collectAsState()
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true) JarvisVoiceService.start(ctx)
    }
    val active = state != VoiceState.IDLE && state != VoiceState.ERROR
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {
        Text("JARVIS", style = MaterialTheme.typography.displayMedium)
        Spacer(Modifier.height(8.dp))
        Text(state.name, style = MaterialTheme.typography.titleMedium)
        error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.height(32.dp))
        Button(onClick = {
            if (active) JarvisVoiceService.stop(ctx)
            else perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS))
        }) { Text(if (active) "Stop" else "Start conversation") }
        TextButton(onClick = openSettings) { Text("Settings") }
    }
}

@Composable
fun SettingsScreen(app: JarvisApp, back: () -> Unit) {
    val scope = rememberCoroutineScope()
    var keyInput by remember { mutableStateOf("") }
    var hasKey by remember { mutableStateOf(app.keyStore.has()) }
    var status by remember { mutableStateOf<String?>(null) }
    var model by remember { mutableStateOf(app.config.liveModel) }

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)
        Text(if (hasKey) "API key: saved (hidden)" else "API key: not set")
        OutlinedTextField(keyInput, { keyInput = it }, Modifier.fillMaxWidth(),
            label = { Text(if (hasKey) "Replace API key" else "Gemini API key") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = keyInput.isNotBlank(), onClick = {
                app.keyStore.save(keyInput); keyInput = ""; hasKey = true; status = "Saved"
            }) { Text("Save") }
            OutlinedButton(onClick = {
                val k = keyInput.ifBlank { app.keyStore.get().orEmpty() }
                if (k.isBlank()) status = "Enter a key first" else {
                    status = "Testing…"
                    scope.launch { status = GeminiApi.testKey(k) ?: "Key works ✓" }
                }
            }) { Text("Test") }
            OutlinedButton(enabled = hasKey, onClick = {
                app.keyStore.delete(); hasKey = false; status = "Deleted"
            }) { Text("Delete") }
        }
        status?.let { Text(it) }
        HorizontalDivider()
        OutlinedTextField(model, { model = it; app.config.liveModel = it }, Modifier.fillMaxWidth(),
            label = { Text("Live model name") }, singleLine = true)
        TextButton(onClick = back) { Text("Back") }
    }
}
