package com.jarvis.ai

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** API key lives only here, encrypted with Android Keystore. Never log or display it. */
class SecureKeyStore(ctx: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        ctx, "jarvis_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    fun save(key: String) = prefs.edit().putString(K, key.trim()).apply()
    fun get(): String? = prefs.getString(K, null)?.takeIf { it.isNotBlank() }
    fun has(): Boolean = get() != null
    fun delete() = prefs.edit().remove(K).apply()
    private companion object { const val K = "gemini_key" }
}
