package com.jarvis.voice

import android.media.*
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.max

/** Streams Gemini's 24 kHz PCM reply to the speaker; supports barge-in flush and drain callback. */
class AudioPlayer(private val onDrained: () -> Unit) {
    private val q = LinkedBlockingQueue<Any>()
    private val end = Any()
    @Volatile private var running = true
    private val track: AudioTrack
    private val worker: Thread

    init {
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(max(min, 48000))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        track.play()
        worker = Thread {
            try {
                while (running) {
                    val item = q.take()
                    if (item is ByteArray) track.write(item, 0, item.size) else onDrained()
                }
            } catch (_: InterruptedException) {}
        }.also { it.start() }
    }

    fun enqueue(pcm: ByteArray) { q.put(pcm) }
    fun markTurnEnd() { q.put(end) }
    fun flush() { q.clear(); track.pause(); track.flush(); track.play() }
    fun release() { running = false; worker.interrupt(); track.runCatching { stop(); release() } }
}
