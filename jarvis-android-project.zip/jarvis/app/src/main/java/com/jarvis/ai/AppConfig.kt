package com.jarvis.ai

import android.content.Context

/** Non-secret, user-configurable settings. Model names are never hard-coded elsewhere. */
class AppConfig(ctx: Context) {
    private val p = ctx.getSharedPreferences("jarvis_config", Context.MODE_PRIVATE)
    var liveModel: String
        get() = p.getString("live_model", DEFAULT_LIVE_MODEL)!!
        set(v) = p.edit().putString("live_model", v.trim()).apply()
    var textModel: String
        get() = p.getString("text_model", DEFAULT_TEXT_MODEL)!!
        set(v) = p.edit().putString("text_model", v.trim()).apply()
    var systemPrompt: String
        get() = p.getString("system_prompt", DEFAULT_PROMPT)!!
        set(v) = p.edit().putString("system_prompt", v).apply()

    companion object {
        const val DEFAULT_LIVE_MODEL = "gemini-3.8-live"
        const val DEFAULT_TEXT_MODEL = "gemini-2.5-flash"
        const val DEFAULT_PROMPT =
            "You are JARVIS, a concise, capable personal AI assistant. Reply in the user's language. " +
            "Use the provided tools when they help accomplish a request."
    }
}
