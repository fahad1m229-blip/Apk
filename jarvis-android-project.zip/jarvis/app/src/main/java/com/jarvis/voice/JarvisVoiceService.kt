package com.jarvis.voice

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.jarvis.JarvisApp
import com.jarvis.ai.GeminiLiveClient
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.json.JSONObject

/**
 * Owns the whole loop: mic -> Gemini Live -> speaker -> mic. State machine:
 * CONNECTING -> LISTENING -> PROCESSING -> SPEAKING -> LISTENING ...
 */
class JarvisVoiceService : Service(), GeminiLiveClient.Listener {
    companion object {
        private val _state = MutableStateFlow(VoiceState.IDLE)
        val state = _state.asStateFlow()
        private val _error = MutableStateFlow<String?>(null)
        val error = _error.asStateFlow()
        fun start(c: Context) = ContextCompat.startForegroundService(c, Intent(c, JarvisVoiceService::class.java))
        fun stop(c: Context) { c.stopService(Intent(c, JarvisVoiceService::class.java)) }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var client: GeminiLiveClient? = null
    private var capture: AudioCapture? = null
    private var player: AudioPlayer? = null
    @Volatile private var turnOpen = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "JARVIS", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "jarvis").setContentTitle("JARVIS is active")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        connect()
        return START_NOT_STICKY
    }

    private fun connect() {
        val app = application as JarvisApp
        val key = app.keyStore.get()
        if (key == null) { fail("Add your Gemini API key in Settings."); return }
        _error.value = null; _state.value = VoiceState.CONNECTING
        client = GeminiLiveClient(this).also {
            it.connect(key, app.config.liveModel, app.config.systemPrompt, app.tools.declarations())
        }
    }

    // ---- Gemini events ----
    override fun onReady() {
        player = AudioPlayer { if (!turnOpen) _state.value = VoiceState.LISTENING }
        capture = AudioCapture(
            onChunk = { client?.sendAudio(it) },
            onSpeech = { speaking ->
                if (!speaking && _state.value == VoiceState.LISTENING) _state.value = VoiceState.PROCESSING
            }
        ).also { it.start() }
        _state.value = VoiceState.LISTENING
    }

    override fun onAudio(pcm24k: ByteArray) {
        turnOpen = true
        _state.value = VoiceState.SPEAKING
        player?.enqueue(pcm24k)
    }

    override fun onInterrupted() { // user barged in
        turnOpen = false; player?.flush(); _state.value = VoiceState.LISTENING
    }

    override fun onTurnComplete() { turnOpen = false; player?.markTurnEnd() } // -> LISTENING once audio drains

    override fun onToolCall(id: String, name: String, args: JSONObject) {
        _state.value = VoiceState.PROCESSING
        scope.launch {
            val result = (application as JarvisApp).tools.run(name, args)
            client?.sendToolResult(id, name, result)
        }
    }

    override fun onError(msg: String) = fail(msg)
    override fun onClosed() { if (_state.value != VoiceState.ERROR) _state.value = VoiceState.IDLE }

    private fun fail(msg: String) { _error.value = msg; _state.value = VoiceState.ERROR; teardown(); stopSelf() }

    private fun teardown() {
        capture?.stop(); capture = null
        player?.release(); player = null
        client?.close(); client = null
    }

    override fun onDestroy() {
        teardown(); scope.cancel()
        if (_state.value != VoiceState.ERROR) _state.value = VoiceState.IDLE
        super.onDestroy()
    }
}
