package com.jarvis.tools

import android.content.Context
import android.os.BatteryManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

/** Every capability JARVIS can use. Gemini picks tools by name via function calling. */
interface JarvisTool {
    val name: String
    val description: String
    val parameters: JSONObject? get() = null   // JSON-schema object, or null for no args
    suspend fun execute(args: JSONObject): JSONObject
}

class ToolRegistry {
    private val tools = linkedMapOf<String, JarvisTool>()
    fun register(t: JarvisTool) { tools[t.name] = t }

    fun declarations(): JSONArray {
        if (tools.isEmpty()) return JSONArray()
        val fns = JSONArray()
        tools.values.forEach { t ->
            fns.put(JSONObject().put("name", t.name).put("description", t.description)
                .apply { t.parameters?.let { put("parameters", it) } })
        }
        return JSONArray().put(JSONObject().put("functionDeclarations", fns))
    }

    suspend fun run(name: String, args: JSONObject): JSONObject = try {
        tools[name]?.execute(args) ?: JSONObject().put("error", "Unknown tool: $name")
    } catch (e: Exception) { JSONObject().put("error", e.javaClass.simpleName) }
}

class GetTimeTool : JarvisTool {
    override val name = "get_current_time"
    override val description = "Returns the device's current date and time."
    override suspend fun execute(args: JSONObject) = JSONObject().put("time",
        SimpleDateFormat("EEEE, d MMMM yyyy HH:mm", Locale.getDefault()).format(Date()))
}

class BatteryTool(private val ctx: Context) : JarvisTool {
    override val name = "get_battery_level"
    override val description = "Returns the phone's battery percentage."
    override suspend fun execute(args: JSONObject): JSONObject {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return JSONObject().put("percent", bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY))
    }
}
