package com.jarvis.voice

enum class VoiceState { IDLE, CONNECTING, LISTENING, PROCESSING, SPEAKING, ERROR }
