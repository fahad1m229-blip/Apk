package com.jarvis.voice

import android.annotation.SuppressLint
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import kotlin.math.abs
import kotlin.math.max

/** Continuous 16 kHz mono mic capture. Mic stays open for the whole session (no manual toggling). */
@SuppressLint("MissingPermission")
class AudioCapture(
    private val onChunk: (ByteArray) -> Unit,
    private val onSpeech: (Boolean) -> Unit   // UI hint only; Gemini's server VAD decides real end-of-speech
) {
    private var rec: AudioRecord? = null
    private var thread: Thread? = null
    @Volatile private var running = false

    fun start() {
        val rate = 16000; val chunk = 3200 // 100 ms
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, chunk * 4))
        if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(r.audioSessionId)?.enabled = true
        if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(r.audioSessionId)?.enabled = true
        rec = r; running = true; r.startRecording()
        thread = Thread {
            val buf = ByteArray(chunk)
            var speaking = false; var quiet = 0
            while (running) {
                val n = r.read(buf, 0, chunk)
                if (n <= 0) continue
                onChunk(buf.copyOf(n))
                var sum = 0L
                for (i in 0 until n - 1 step 2) sum += abs(((buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)).toShort().toInt())
                val loud = sum / (n / 2) > 900
                if (loud) { quiet = 0; if (!speaking) { speaking = true; onSpeech(true) } }
                else if (speaking && ++quiet >= 7) { speaking = false; onSpeech(false) } // ~700 ms silence
            }
        }.also { it.start() }
    }

    fun stop() {
        running = false
        thread?.join(300)
        rec?.runCatching { stop(); release() }
        rec = null
    }
}
