package com.jarvis.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object GeminiApi {
    private val http = OkHttpClient.Builder().callTimeout(15, TimeUnit.SECONDS).build()

    /** Returns null on success, otherwise a safe error message (never contains the key). */
    suspend fun testKey(key: String): String? = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1")
                .header("x-goog-api-key", key.trim()).build()
            http.newCall(req).execute().use { r ->
                when {
                    r.isSuccessful -> null
                    r.code == 400 || r.code == 403 -> "Invalid API key (${r.code})"
                    else -> "Server error (${r.code})"
                }
            }
        } catch (e: Exception) { "Network error: ${e.javaClass.simpleName}" }
    }
}
